// Calculate Chrome extension ID from a PEM private key file
const crypto = require('crypto');
const fs = require('fs');

const pemPath = process.argv[2];
if (!pemPath) {
    console.error('Usage: node calc_id.js <path-to-pem>');
    process.exit(1);
}

const pemContent = fs.readFileSync(pemPath, 'utf8');

// Create a public key object from the private key
const privateKey = crypto.createPrivateKey(pemContent);
const publicKey = crypto.createPublicKey(privateKey);

// Export public key in DER format (SubjectPublicKeyInfo / SPKI)
const pubKeyDer = publicKey.export({ type: 'spki', format: 'der' });

// Compute SHA-256 hash of the DER-encoded public key
const hash = crypto.createHash('sha256').update(pubKeyDer).digest();

// Take first 16 bytes
const first16 = hash.subarray(0, 16);

// Convert to hex string
const hexStr = first16.toString('hex');

// Map: 0-9 → a-j, a-f → k-p
const mapped = hexStr.split('').map(c => {
    if (c >= '0' && c <= '9') {
        return String.fromCharCode(c.charCodeAt(0) + 49); // '0'→'a', '9'→'j'
    } else {
        return String.fromCharCode(c.charCodeAt(0) + 10); // 'a'→'k', 'f'→'p'
    }
}).join('');

console.log('Extension ID:', mapped);
console.log('Hex hash (first 16 bytes):', hexStr);
