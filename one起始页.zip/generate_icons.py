"""
Generate PNG icons for Chrome extension using only Python standard library.
Creates simple but clean gradient icons with a clock/search motif.
"""
import struct
import zlib
import math
import os

def create_png(width, height, pixels):
    """Create a PNG file from RGBA pixel data."""
    def make_chunk(chunk_type, data):
        chunk = chunk_type + data
        crc = struct.pack('>I', zlib.crc32(chunk) & 0xFFFFFFFF)
        return struct.pack('>I', len(data)) + chunk + crc

    # PNG signature
    signature = b'\x89PNG\r\n\x1a\n'

    # IHDR chunk
    ihdr_data = struct.pack('>IIBBBBB', width, height, 8, 6, 0, 0, 0)  # 8-bit, RGBA
    ihdr = make_chunk(b'IHDR', ihdr_data)

    # IDAT chunk - pixel data with filter byte per row
    raw_data = b''
    for y in range(height):
        raw_data += b'\x00'  # filter: none
        for x in range(width):
            idx = (y * width + x) * 4
            raw_data += bytes(pixels[idx:idx+4])
    compressed = zlib.compress(raw_data, 9)
    idat = make_chunk(b'IDAT', compressed)

    # IEND chunk
    iend = make_chunk(b'IEND', b'')

    return signature + ihdr + idat + iend


def lerp_color(c1, c2, t):
    """Linear interpolation between two RGB colors."""
    return tuple(int(c1[i] + (c2[i] - c1[i]) * t) for i in range(3))


def generate_icon(size):
    """Generate a gradient icon with a circular search/clock motif."""
    pixels = bytearray(size * size * 4)

    cx = size / 2
    cy = size / 2

    # Gradient colors: dark blue to lighter blue/purple
    top_color = (45, 55, 89)       # dark blue-gray
    bottom_color = (72, 85, 120)    # slightly lighter

    # Accent color for the circle motif
    accent = (255, 165, 60)  # warm orange, matching the news button
    circle_radius = size * 0.30
    ring_thickness = max(1, size * 0.05)

    for y in range(size):
        for x in range(size):
            idx = (y * size + x) * 4

            # Gradient background
            t = y / max(size - 1, 1)
            bg = lerp_color(top_color, bottom_color, t)

            r, g, b = bg

            # Draw a ring (circle outline)
            dist = math.sqrt((x - cx) ** 2 + (y - cy) ** 2)
            if abs(dist - circle_radius) < ring_thickness:
                r, g, b = accent
            # Draw clock hands (simple lines from center)
            elif dist < circle_radius:
                # Hour hand: pointing up-right
                angle_h = -math.pi / 4  # 45 degrees
                hx = cx + math.cos(angle_h) * circle_radius * 0.45
                hy = cy + math.sin(angle_h) * circle_radius * 0.45
                # Check if pixel is on the hour hand line
                dx_h = hx - cx
                dy_h = hy - cy
                len_h = math.sqrt(dx_h**2 + dy_h**2)
                if len_h > 0:
                    # Point to line distance
                    px = x - cx
                    py = y - cy
                    cross = abs(px * dy_h - py * dx_h) / len_h
                    dot = (px * dx_h + py * dy_h) / (len_h * len_h)
                    if cross < ring_thickness * 0.6 and 0 <= dot <= 1:
                        r, g, b = accent

                # Minute hand: pointing up
                angle_m = -math.pi / 2  # straight up
                mx = cx + math.cos(angle_m) * circle_radius * 0.65
                my = cy + math.sin(angle_m) * circle_radius * 0.65
                dx_m = mx - cx
                dy_m = my - cy
                len_m = math.sqrt(dx_m**2 + dy_m**2)
                if len_m > 0:
                    px = x - cx
                    py = y - cy
                    cross = abs(px * dy_m - py * dx_m) / len_m
                    dot = (px * dx_m + py * dy_m) / (len_m * len_m)
                    if cross < ring_thickness * 0.6 and 0 <= dot <= 1:
                        r, g, b = accent

            # Rounded corners
            corner_radius = size * 0.12
            if x < corner_radius and y < corner_radius:
                d = math.sqrt((corner_radius - x)**2 + (corner_radius - y)**2)
                if d > corner_radius:
                    a = 0
                else:
                    a = 255
            elif x > size - corner_radius - 1 and y < corner_radius:
                d = math.sqrt((x - (size - corner_radius - 1))**2 + (corner_radius - y)**2)
                if d > corner_radius:
                    a = 0
                else:
                    a = 255
            elif x < corner_radius and y > size - corner_radius - 1:
                d = math.sqrt((corner_radius - x)**2 + (y - (size - corner_radius - 1))**2)
                if d > corner_radius:
                    a = 0
                else:
                    a = 255
            elif x > size - corner_radius - 1 and y > size - corner_radius - 1:
                d = math.sqrt((x - (size - corner_radius - 1))**2 + (y - (size - corner_radius - 1))**2)
                if d > corner_radius:
                    a = 0
                else:
                    a = 255
            else:
                a = 255

            pixels[idx] = r
            pixels[idx + 1] = g
            pixels[idx + 2] = b
            pixels[idx + 3] = a

    return pixels


def main():
    icon_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'icons')
    os.makedirs(icon_dir, exist_ok=True)

    for size in [16, 48, 128]:
        print(f"Generating {size}x{size} icon...")
        pixels = generate_icon(size)
        png_data = create_png(size, size, pixels)
        icon_path = os.path.join(icon_dir, f'icon{size}.png')
        with open(icon_path, 'wb') as f:
            f.write(png_data)
        print(f"  Saved: {icon_path}")

    print("All icons generated successfully!")


if __name__ == '__main__':
    main()
