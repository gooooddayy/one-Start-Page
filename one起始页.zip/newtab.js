// 搜索引擎配置
const searchEngines = {
    baidu: 'https://www.baidu.com/s?wd=',
    bing: 'https://www.bing.com/search?q=',
    google: 'https://www.google.com/search?q='
};

let currentEngine = 'bing';
const WALLPAPER_API = 'https://wp.upx8.com/api.php?category=nature';
let isLoadingWallpaper = false;

// 更新时间
function updateTime() {
    const now = new Date();
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    const seconds = String(now.getSeconds()).padStart(2, '0');

    document.getElementById('time').textContent = `${hours}:${minutes}:${seconds}`;

    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const day = String(now.getDate()).padStart(2, '0');
    const weekdays = ['星期日', '星期一', '星期二', '星期三', '星期四', '星期五', '星期六'];
    const weekday = weekdays[now.getDay()];

    document.getElementById('date').textContent = `${year}年${month}月${day}日 ${weekday}`;
}

// 加载壁纸
async function loadWallpaper() {
    if (isLoadingWallpaper) return;
    isLoadingWallpaper = true;

    const hint = document.getElementById('loadingHint');
    const btn = document.getElementById('wallpaperBtn');
    hint.style.display = 'block';
    hint.textContent = '正在加载壁纸...';

    const btnSvg = btn.querySelector('svg');
    btnSvg.classList.add('spinning');

    const apiUrl = `${WALLPAPER_API}&t=${new Date().getTime()}`;

    // 应用壁纸
    const applyWallpaper = (url) => {
        const img = new Image();
        img.onload = function() {
            document.getElementById('wallpaper').style.backgroundImage = `url("${url}")`;
            hint.style.display = 'none';
            btnSvg.classList.remove('spinning');
            isLoadingWallpaper = false;
        };
        img.onerror = function() {
            hint.textContent = '壁纸加载失败，点击重试';
            btnSvg.classList.remove('spinning');
            isLoadingWallpaper = false;
        };
        img.src = url;
    };

    try {
        const response = await fetch(apiUrl, { method: 'GET', redirect: 'follow' });
        let wallpaperUrl = response.url;
        if (wallpaperUrl.startsWith('http://')) {
            wallpaperUrl = wallpaperUrl.replace('http://', 'https://');
        }
        applyWallpaper(wallpaperUrl);
    } catch (error) {
        console.error('解析壁纸地址失败，直接加载接口地址:', error);
        // 兜底：直接把接口地址作为图片源，交给浏览器跟随跳转
        applyWallpaper(apiUrl);
    }
}

// 搜索引擎切换
document.querySelectorAll('.engine-btn').forEach(btn => {
    btn.addEventListener('click', function() {
        document.querySelectorAll('.engine-btn').forEach(b => b.classList.remove('active'));
        this.classList.add('active');
        currentEngine = this.dataset.engine;
    });
});

// 搜索功能
function performSearch() {
    const query = document.getElementById('searchInput').value.trim();
    if (query) {
        const searchUrl = searchEngines[currentEngine] + encodeURIComponent(query);
        window.open(searchUrl, '_blank');
    }
}

document.getElementById('submitBtn').addEventListener('click', performSearch);

document.getElementById('searchInput').addEventListener('keypress', function(e) {
    if (e.key === 'Enter') {
        performSearch();
    }
});

// 清除搜索内容
function clearSearch() {
    const input = document.getElementById('searchInput');
    input.value = '';
    input.focus();
    document.getElementById('clearBtn').classList.remove('show');
}

document.getElementById('clearBtn').addEventListener('click', clearSearch);
document.getElementById('clearHint').addEventListener('click', clearSearch);

// 监听输入框
document.getElementById('searchInput').addEventListener('input', function() {
    const clearBtn = document.getElementById('clearBtn');
    if (this.value.length > 0) {
        clearBtn.classList.add('show');
    } else {
        clearBtn.classList.remove('show');
    }
});

// 壁纸切换按钮
document.getElementById('wallpaperBtn').addEventListener('click', loadWallpaper);

// 60s新闻功能
let newsLoaded = false;
let newsLoading = false;

async function loadNews() {
    if (newsLoading) return;
    newsLoading = true;

    const body = document.getElementById('newsModalBody');
    body.innerHTML = '<div class="news-loading"><div class="loader"></div>正在获取新闻...</div>';

    try {
        // 动态生成今天的日期
        const now = new Date();
        const year = now.getFullYear();
        const month = String(now.getMonth() + 1).padStart(2, '0');
        const day = String(now.getDate()).padStart(2, '0');
        const dateStr = `${year}-${month}-${day}`;

        const apiUrl = `https://60s-static.viki.moe/60s/${dateStr}.json`;

        const response = await fetch(apiUrl);
        if (!response.ok) throw new Error('HTTP ' + response.status);
        const data = await response.json();

        let html = '';

        if (data.news && Array.isArray(data.news) && data.news.length > 0) {
            data.news.forEach((item, index) => {
                html += `<div class="news-item"><span class="news-index">${index + 1}</span><span>${item.trim()}</span></div>`;
            });
        } else {
            html += '<div class="news-error">暂无新闻数据，请稍后重试</div>';
        }

        if (data.tip && data.tip.trim()) {
            html += `<div class="news-weiyu">【微语】${data.tip.trim()}</div>`;
        }

        body.innerHTML = html;
        newsLoaded = true;
    } catch (error) {
        console.error('新闻加载失败:', error);
        body.innerHTML = '<div class="news-error">新闻加载失败，请稍后重试</div>';
    }

    newsLoading = false;
}

// 打开新闻弹窗
document.getElementById('newsBtn').addEventListener('click', function() {
    document.getElementById('newsModal').classList.add('show');
    if (!newsLoaded) {
        loadNews();
    }
});

// 关闭新闻弹窗
document.getElementById('newsCloseBtn').addEventListener('click', function() {
    document.getElementById('newsModal').classList.remove('show');
});

// 点击遮罩关闭
document.getElementById('newsModal').addEventListener('click', function(e) {
    if (e.target === this) {
        this.classList.remove('show');
    }
});

// ESC关闭弹窗
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        document.getElementById('newsModal').classList.remove('show');
    }
});

// 初始化
updateTime();
setInterval(updateTime, 1000);
loadWallpaper();

document.getElementById('searchInput').focus();
