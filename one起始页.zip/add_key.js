// Extract public key from PEM and add it to manifest.json
const crypto = require('crypto');
const fs = require('fs');

const pemPath = 'C:/Users/Administrator/WorkBuddy/2026-07-27-15-56-26/one-start-page.pem';
const manifestPath = 'C:/Users/Administrator/WorkBuddy/2026-07-27-15-56-26/one-start-page/manifest.json';

const pemContent = fs.readFileSync(pemPath, 'utf8');
const privateKey = crypto.createPrivateKey(pemContent);
const publicKey = crypto.createPublicKey(privateKey);

// Export public key in DER format
const pubKeyDer = publicKey.export({ type: 'spki', format: 'der' });

// Base64 encode (no headers, just the raw DER)
const pubKeyBase64 = pubKeyDer.toString('base64');

// Read manifest and add the key field
const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
manifest.key = pubKeyBase64;

// Write back
fs.writeFileSync(manifestPath, JSON.stringify(manifest, null, 2));

console.log('Public key (base64):', pubKeyBase64);
console.log('Manifest updated with key field');

// Also verify the extension ID
const hash = crypto.createHash('sha256').update(pubKeyDer).digest();
const first16 = hash.subarray(0, 16);
const hexStr = first16.toString('hex');
const mapped = hexStr.split('').map(c => {
    if (c >= '0' && c <= '9') return String.fromCharCode(c.charCodeAt(0) + 49);
    else return String.fromCharCode(c.charCodeAt(0) + 10);
}).join('');
console.log('Verified Extension ID:', mapped);
